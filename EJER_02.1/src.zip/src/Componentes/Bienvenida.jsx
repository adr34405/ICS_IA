export function Bienvenida() {
  return (
    <section>
      <span role="img" aria-label="Graduación">
        🎓
      </span>
      <p>Bienvenido al módulo de Desarrollo Web en Entorno Cliente.</p>
    </section>
  );
}
